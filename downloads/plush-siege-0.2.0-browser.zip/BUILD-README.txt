PLUSH SIEGE 0.2.0 - Physics and gameplay feel

Extract all files and serve this directory at the origin root using a static HTTP server, for example:
  python -m http.server 8080
Open the server address in a browser. Opening index.html directly as a file is unsupported.

Use HTTPS for access from an iPad and PWA installation. Load online once and allow the service worker to activate before offline play. All game assets are included; no backend or account required.

Source, npm setup instructions, tests, and the development report are at https://github.com/KC2012/plushsiege . Physical iPad Safari remains unverified.
