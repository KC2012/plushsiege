PLUSH SIEGE 0.4.0 — THE GREAT EXPANSION

70 verified levels in five worlds. Original graphics, music and sound are bundled.
No account, CDN, API key or gameplay backend is required.

Extract this folder and serve it from the root of a local HTTP/HTTPS server.
For example, with Python installed, open a terminal here and run:
  python -m http.server 8080
Then open http://localhost:8080 in a browser.

Do not open index.html directly using file://. The game requires an HTTP/HTTPS
origin for JavaScript modules, offline caching and installable app behavior.

For source development instead, download the repository ZIP, extract it, and
run npm ci followed by npm run dev in the folder containing package.json.
Use Node.js 24 or newer.

PLAY resumes the campaign. Worlds opens five destinations. Overview/Sling and
-/+ inspect large levels; drag empty scenery to pan and pinch/wheel to zoom.
Pull a stuffie back and release. Tap during flight or press Space for its ability.
R restarts; Escape pauses. Settings includes separate music/effects volumes.

Load the production game online once, let its service worker activate, then
reload before testing offline. On iPad, Safari Add to Home Screen can install it.
Physical iPad Safari performance, audio latency and installation UX still need
on-device review. Progress saves locally to this browser; it is not a cloud save.

The 150-level milestone remains future work: 80 additional reviewed levels.
See the source repository's docs/pass-4-report.md for verification and limitations.
Dependency license notices are included in third-party-notices.txt.
