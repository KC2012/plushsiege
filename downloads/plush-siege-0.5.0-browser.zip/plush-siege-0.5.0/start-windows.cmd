@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 24, then run this launcher again.
  pause
  exit /b 1
)
node serve.mjs
if errorlevel 1 pause
