PLUSH SIEGE 0.3.0 - Monster physics and graphic cartoon overhaul

Extract ALL files and serve this directory at the origin root using a static HTTP server, e.g.:
  python -m http.server 8080
Open the server address in a browser. Direct file:// opening is unsupported.

The game is index.html; the visual physics tool is physics-lab.html on the same server. Use HTTPS for access from an iPad/PWA installation. Load online once so the worker can activate before offline play.

No backend, accounts or paid APIs. Save key remains plush-siege-v1; existing progress/settings are compatible. Physical iPad Safari remains unverified.
Source/setup/tests/report: https://github.com/KC2012/plushsiege
